import TestEnd from "../test/TestEnd";
import classes from "./page.module.css";

const TestEndPage = () => {
  return (
    <section className={classes.wrapper}>
      <TestEnd />
    </section>
  );
};

export default TestEndPage;
