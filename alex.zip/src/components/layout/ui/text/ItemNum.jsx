const ItemNum = (props) => {
  return <span className={props.className}>{props.children}</span>;
}

export default ItemNum;