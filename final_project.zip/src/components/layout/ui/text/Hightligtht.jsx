const Highlight = (props) => {
  return <span className={props.className}>{props.children}</span>
}

export default Highlight;