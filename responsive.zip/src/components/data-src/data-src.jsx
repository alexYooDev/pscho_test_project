export const API_KEY = 'a72cbf8ac59de7c7968bd99e69950998';
export const CAT_NUM = "6";
export const MAN = "100323";
export const WOMAN = "100324";
export const TRGET_SEQ = "100209";

export const TEST_URL = `https://www.career.go.kr/inspct/openapi/test/questions?apikey=${API_KEY}&q=${CAT_NUM}`;
export const RESULT_URL = `https://www.career.go.kr/inspct/openapi/test/report?apikey=${API_KEY}&qestrnSeq=${CAT_NUM}`;